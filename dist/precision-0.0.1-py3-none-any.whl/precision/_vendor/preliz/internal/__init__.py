"""utility functions for internal use."""
