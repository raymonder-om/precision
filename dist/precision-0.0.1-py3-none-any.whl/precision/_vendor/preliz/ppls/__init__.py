"""Functions for interacting with probabilistic programming languages."""
