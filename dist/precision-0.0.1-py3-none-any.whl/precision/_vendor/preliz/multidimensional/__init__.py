from preliz.multidimensional.dirichlet_mode import dirichlet_mode

__all__ = ["dirichlet_mode"]
