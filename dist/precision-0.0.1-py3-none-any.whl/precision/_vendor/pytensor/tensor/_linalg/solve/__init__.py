# Register rewrites in the database
import pytensor.tensor._linalg.solve.rewriting
